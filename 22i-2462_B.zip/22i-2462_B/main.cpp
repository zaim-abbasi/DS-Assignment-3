// Zaim Khan Abbasi_22I-2462_Assignment 3
#include "menu.h"
int main()
{
    Menu();
    return 0;
}